import "firebase/compat/auth";
import firebase from "firebase/compat/app";
// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCR7tEtI45WxjjgGdPpzQzglcamHdIxYmg",
  authDomain: "todo-mongo-57049.firebaseapp.com",
  projectId: "todo-mongo-57049",
  storageBucket: "todo-mongo-57049.appspot.com",
  messagingSenderId: "819268211162",
  appId: "1:819268211162:web:f44033b4e21a6e7706b0e3",
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
export default firebase;