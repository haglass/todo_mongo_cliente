import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import "bootstrap/dist/css/bootstrap.css";
import App from "./App";
// redux-toolkit 적용
import store from "./reducer/store";

// store를 Provider 를 이용해서 울타리친다.
// store를 사용할 childe 들을 설정한다.
import { Provider } from "react-redux";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  // Provider 필수 store={store}
  <Provider store={store}>
    <App />
  </Provider>
);
