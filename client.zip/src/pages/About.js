import React from "react";

const About = () => {
  return <div className="p-6 m-4 shadow">About</div>;
};

export default About;